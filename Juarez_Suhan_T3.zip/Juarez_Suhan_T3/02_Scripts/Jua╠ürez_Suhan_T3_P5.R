#### Redes de interacción proteína-proteína####

# Selecciona tres redes pequeñas, alrededor de 100 proteínas, y elabora un programa en R que:

################# PARTE 1
# Lea las redes en R y determine la distribución de conectividades
library(igraph)

# Cargamos las listas de adyacencia, de la base de datos, de Phytoplasma, Ureaplasma y Lachnospiraceae:
Phytoplasma<-read.table(file = "01_Raw_data/treeoflife.interactomes/37692.txt")
Ureaplasma<-read.table(file = "01_Raw_data/treeoflife.interactomes/273119.txt")
Lachnospiraceae<-read.table(file = "01_Raw_data/treeoflife.interactomes/742723.txt")

# Después, revisamos la información:
graph_from_data_frame(Phytoplasma, directed = TRUE) ->PhytoplasmaRed
PhytoplasmaRed
graph_from_data_frame(Ureaplasma, directed = TRUE) ->UreaplasmaRed
UreaplasmaRed
graph_from_data_frame(Lachnospiraceae, directed = TRUE) ->LachnospiraceaeRed
LachnospiraceaeRed

# Revisamos la distribución de conectividades para cada una, en una gráfica:
hist(degree_distribution(PhytoplasmaRed), main = "Phytoplasma degree distribution", xlab = "Degree distribution", col = "deepskyblue2")
hist(degree_distribution(UreaplasmaRed), main = "Ureaplasma degree distribution", xlab = "Degree distribution", col = "khaki")
hist(degree_distribution(LachnospiraceaeRed), main = "Lachnospiraceae degree distribution", xlab = "Degree distribution", col = "mediumseagreen")

################# PARTE 2
# Calcule el promedio de conectividades de cada red
mean(degree(PhytoplasmaRed))
mean(degree(UreaplasmaRed))
mean(degree(LachnospiraceaeRed))

################# PARTE 3
# Calcule la densidad de cada red
# La densidad de un gráfico es la relación entre el número de conexiones existentes y el número de conexiones posibles.
edge_density(PhytoplasmaRed, loops = FALSE) # Asumiendo que no tenemos bucles
edge_density(PhytoplasmaRed, loops = TRUE) # Asumiendo que tenemos bucles


edge_density(UreaplasmaRed, loops = FALSE) 
edge_density(UreaplasmaRed, loops = TRUE)

edge_density(LachnospiraceaeRed, loops = FALSE) 
edge_density(LachnospiraceaeRed, loops = TRUE)

################# PARTE 4
# Escribe una función que muestre el número de componentes de la red cuando se desconectan los 10 nodos más conectados. 
# La función de igraph components() puede ser  útil, la aplicamos:

## Con la siguiente función agregamos la red, seguido de una coma, y el número de nodos a eliminar (ojo siempre serán los más grandes)

Attack_to_components<- function (Net, EdgesN){
   
Miembros<-c()
i<- 1
   while(i <= EdgesN){
     Cxs<-degree(Net)
     Nodo<-Cxs[which(Cxs == max(Cxs))]
     Net<-delete_vertices(Net, Nodo)
     Miembros<-c(Miembros, components(Net))
     i<- i+1
   }
    
  return(Miembros)
}


######
# Aplicamos la función con 10 nodos, nos devolverán todos los componentes conectados (el nodo y debajo el grupo al que pertenecen)

Attack_to_components(PhytoplasmaRed, 10)
Attack_to_components(UreaplasmaRed, 10)
Attack_to_components(LachnospiraceaeRed, 10)

# Haganos hincapié a $csize que muestra unvector numérico con los tamaños de los grupos.
# Y al valor $no que índica el número de clusters


################# PARTE 5
#  Calcule la robustez de las redes quitando los 10 proteínas máas conectadas
# Esto se puede realizar de varias formas, por ejemplo, con el diámetro 
Robust_to_diameter<- function (Net, EdgesN){
  
  Robustez<-c()
  i<- 1
  while(i <= EdgesN){
    Cxs<-degree(Net)
    Nodo<-Cxs[which(Cxs == max(Cxs))]
    Net<-delete_vertices(Net, Nodo)
    Robustez<-c(Robustez, diameter(Net))
    i<- i+1
  }
  
  return(Robustez)
}

# Aplicamos la función con 10 nodos,

Robust_to_diameter(PhytoplasmaRed, 10)
Robust_to_diameter(UreaplasmaRed, 10)
Robust_to_diameter(LachnospiraceaeRed, 10)


################# PARTE 6
# Selecciona las 10 proteínas más importantes y determina su función buscando en la literatura. 
# Para identificar las proteínas, usa por el momento, el buscador de google con nombre de la especie + identificador de la proteína.

Max_connected<- function (Net, EdgesN){
    Cxs<-degree(Net)
    Cxsmax<-sort(Cxs, decreasing = TRUE)
    Conectada<- Cxsmax[1:EdgesN]
  return(Conectada)
}

# Aplicamos la función, y se muestra un vector con las 10 proteínas más conectadas con su respectivo degree
Max_connected(PhytoplasmaRed, 10)
Max_connected(UreaplasmaRed, 10)
Max_connected(LachnospiraceaeRed, 10)



################# PARTE 7
#  (Opcional) Grafica las redes con Cytoscape y agrega una gradiente de color para alguna propiedad topológica sobre los nodos de la red

# TRABAJAR LA RED DE IGRAPH CON CYTOSCAPE ####
# Guardar la red

save (PhytoplasmaRed, file ="03_Output/Phytoplasma.RDS")
save (UreaplasmaRed, file ="03_Output/Ureaplasma.RDS")
save (LachnospiraceaeRed, file ="03_Output/Lachnospiraceae.RDS")

# Para recuperar el objeto RDS, load y la dirección donde se encuentra
load ("03_Output/Phytoplasma.RDS")
load ("03_Output/Ureaplasma.RDS")
load ("03_Output/Lachnospiraceae.RDS")

# Abrimos la paquetería paar conectar con Cytoscape 
library(RCy3)
cytoscapePing() # Esto conecta
createNetworkFromIgraph(PhytoplasmaRed, "myIgraph")
createNetworkFromIgraph(UreaplasmaRed, "myIgraph")
createNetworkFromIgraph(LachnospiraceaeRed, "myIgraph")





