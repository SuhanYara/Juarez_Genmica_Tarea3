#### Red de Co-gustos####
# A partir de las dos versiones de la red de co-gustos: la dicotómica (D) y la pesada (P).
# Elabora un programa en R que calcule:
  

################# PARTE 1
# Dibuje la red con al menos tres layouts (D y P) #####
  
# Cargamos la red 
Cogustos<-read.csv2(file = "01_Raw_data/Red de co-gustos 2022.csv")
# Primero, revisamos la tabla, para verificar la información
View(Cogustos) 

# Podemos ver, que la primera columna posee los nombres
# entonces como no deseamos que eso se lea a la hora de hacer la red, colocamos eso en la columna nombres
row.names(Cogustos)<-Cogustos[,1]
Cogustos<-Cogustos[,-1] # Eliminamos esa columna de nombres

# Creamos matriz de correlación
mat_cor<-cor(t(Cogustos)) ## t transposición, para que cambie contraste columnas (persona vs persona)
View(mat_cor)

diag(mat_cor)<-0 ## Eliminamos valores 1, que contrastan uno vs uno mismo y que alterarían nuestros resultados

# Ahora definimos un criterio, para generar la matriz de adyacencia a usar

mat_ady<-(1+mat_cor)/2  #Vamos a usar la diferencia 1 y el valor de correlación entre 2, para cada valor en mat_cor
diag(mat_ady)<-0 # Eliminamos los valores que contrastan un mismo individuo (en la diagonal)
View(mat_ady) # Revisamos la matriz

# Seleccionamos un valor X (0.55), a partir del que generamos la matriz de adyacencia, se sustituirá 1 o 0 según corresponda
mat_ady_CogusD<-ifelse (mat_ady > 0.55, 1, 0) # Sin pesar, con un método para seleccionar valores 
View(mat_ady_CogusD)

# Cargamos igraph
library(igraph)
# Creamos gráfico con el paquete, usando la matriz de adyacencia
red_gustos<-graph_from_adjacency_matrix(mat_ady_CogusD, mode = "undirected")
plot(red_gustos)->Grph_gustosD

# Podemos modificar el estilo de los gráficos, con lo siguiente
layout1<-layout_nicely(red_gustos)
V(red_gustos)$color = "purple"
E(red_gustos)$color = "green"
plot(red_gustos, layout=layout1)
  
layout2<-layout_as_star(red_gustos)
V(red_gustos)$color = "yellow"
E(red_gustos)$color = "black"
plot(red_gustos, layout=layout2, vertex.size=2, edge.arrow.size=.2)

layout3<-layout_as_tree(red_gustos)
V(red_gustos)$color = "salmon"
plot(red_gustos, layout=layout3)

# Para la red pesada (P)
# Vamos a revisar de la tabla de Cogustos, podemos agregar como valor, las calificaciones que cada alumno
# otorga a las series. Entonces, de esa sacamos las calificaciones promedio que cada uno da, y lo guardamos en un vector:

peso<-c(rowMeans(Cogustos))
peso

# Creamos gráfico con el paquete, usando la matriz de adyacencia y le agregamos el peso
red_gustosP<-graph_from_adjacency_matrix(mat_ady_CogusD, mode = "undirected")

# Creamos un nuevo atributo en el nodo llamado "weight"  
red_gustosP<- set_vertex_attr(red_gustosP, "weigth", value = peso)

# verificamos que se incluyó el atributo
vertex_attr(red_gustosP)

# Asignamos al ancho de los bordes en función de ese valor
plot(red_gustosP, vertex.label.color = "black", edge.color = 'black', edge.width = V(red_gustosP)$weigth)

# Podemos modificar el estilo de los gráficos, con lo siguiente:
layout1P<-layout_nicely(red_gustosP)
V(red_gustosP)$color = "purple"
E(red_gustosP)$color = "green"
plot(red_gustosP, edge.width = V(red_gustosP)$weigth, layout=layout1P)

layout2P<-layout_as_star(red_gustosP)
V(red_gustosP)$color = "yellow"
E(red_gustosP)$color = "black"
plot(red_gustosP, edge.width = V(red_gustosP)$weigth, layout=layout2P)

layout3P<-layout_as_tree(red_gustosP)
V(red_gustosP)$color = "salmon"
plot(red_gustosP, edge.width = V(red_gustosP)$weigth, layout=layout3P)




################# PARTE 2
# La distribución de conectividades (D) #####

degree(red_gustos)
hist(degree_distribution(red_gustos)) # Aquí se ven todas las conexiones

hist(degree(red_gustos,mode="in"),col = "blue") # Sólo conexiones de entrada

hist(degree(red_gustos,mode="out"),col = "red") # Sólo conexiones de salida




################# PARTE 3
# Los nodos más conectados (D) ####

# Podemos guardar el degree de los nodos en un vector
Conexs<- degree(red_gustos)

# Acomodarlos de menor a mayor
Conexs<- sort(Conexs)
length(Conexs) # Recordemos cuantos nodos tenemos

# Revisar el mayor o los primeros tres
Conexs[26]
Conexs[24:26]



################# PARTE 4
# Los nodos más importantes con al menos tres medidas de centralidad (D) ####

# Podemos usar el degree, en este ejemplo, al menos los 3 más grandes que corresponden a 21
# Considerar son centrales por ser los más conectados
Conexs[24:26]

##Distancia del camino más corto desde el otro nodo más lejano en el gráfico
eccentricity(red_gustos)->excent
excent
summary(excent)
# Este no fue muy útil, pues para todos es 2. 


# Cercanía centralidad de los vértices
closeness(red_gustos) -> cercania
sort(cercania)
# Podemos ver que SARA es el de mayor cercacanía

# Por lo tanto, SARA es el nodo más importante, en los sentidos mencionados.



################# PARTE 5
# Los clústers obtenidos con al menos tres métodos de clusterización (D y P) ####

# Cluserizamos con un primer método, con la función de abajo:
RedCo_EB<-cluster_edge_betweenness(red_gustos, directed = FALSE)
RedCo_EB
membership(RedCo_EB) ##Aquí aparece el vector de quién pertenece a cada grupo
table(membership(RedCo_EB)) ##Aquí cuantos pertenece a cada grupo
# Tenemos 12, y sólo el primero tiene más de 1 (15)
plot(RedCo_EB, red_gustos)


# Clusterizamos con un segundo método, con la función de abajo:
RedCo_lo<-cluster_louvain(red_gustos)
RedCo_lo
table(membership(RedCo_lo)) ##Aquí cuantos pertenece a cada grupo
# Aquí se muestran 2
plot(RedCo_lo, red_gustos)


# Clusterizamos con un tercer método, con la función de abajo:
RedCo_fg<-cluster_fast_greedy(red_gustos)
RedCo_fg
table(membership(RedCo_fg)) ##Aquí cuantos pertenece a cada grupo
# Aquí también se muestran 2
plot(RedCo_fg, red_gustos)



## Para la red p
vertex_attr(red_gustosP)
# Cluserizamos con un primer método:
RedCoP_i<-cluster_infomap(red_gustosP, v.weights = peso)
RedCoP_i
membership(RedCoP_i)
table(membership(RedCoP_i)) 
# Tenemos 1 sólo grupo
plot(RedCoP_i, red_gustosP, edge.width = V(red_gustosP)$weigth)


# Clusterizamos con un segundo método:
RedCoP_lo<-cluster_louvain(red_gustosP)
RedCoP_lo
table(membership(RedCoP_lo))
# Aquí se muestran 2
plot(RedCoP_lo, red_gustos, edge.width = V(red_gustosP)$weigth)


# Clusterizamos con un tercer método:
RedCoP_fg<-cluster_fast_greedy(red_gustosP)
RedCoP_fg
table(membership(RedCoP_fg)) ##Aquí cuantos pertenece a cada grupo
# Aquí también se muestran 2
plot(RedCoP_fg, red_gustosP, edge.width = V(red_gustosP)$weigth)

################# PARTE 6
# Discute si las redes (D y P) son dirigidas o no ####

################# PARTE 7
# ¿Cómo podrıías encontrar clicas, si las hay? ####

