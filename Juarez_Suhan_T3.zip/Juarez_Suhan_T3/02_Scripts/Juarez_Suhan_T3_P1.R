
#### WGCNA ####

##Network analysis of liver expression data from female mice####

################# PARTE 1
library(WGCNA)
options(stringsAsFactors = FALSE) #Cargamos esta opción previamente, antes de cargar los datos

#Leemos los datos de hígado
femData<- read.csv("01_Raw_data/FemaleLiver-Data/LiverFemale3600.csv")

#Hacemos una revisión de los datos con lo siguientes comandos
dim(femData) #dimensión de la matriz
names(femData) #Nombres de columnas y pacientes
View(femData)

#Ahora eliminamos los datos auxiliares y transponemos los datos de expresión para su posterior análisis
datExpr0<- as.data.frame(t(femData[, -c(1:8)])) #Creamos nueva base y modificamos orden de datos
names(datExpr0)<- femData$substanceBXH #Colocamos nombres
rownames(datExpr0)<-names(femData)[-c(1:8)] 
View(datExpr0)

################# PARTE 2

#Primero buscamos valores y muestras con valores faltantes
gsg<-goodSamplesGenes(datExpr0, verbose = 3) #Este comando filtra muestras con entradas faltantes, en este caso 3
gsg$allOK

#Si la última declaración marca "TRUE", todos los genes pasaron el corte. 
# Sino, debemos remover aquellos genes que no cumplen. En este caso pasó.

#Ahora clusterizamos las muestras
sampleTree<-hclust(dist(datExpr0), method = "average")
# Ploteamos el árbol en una ventana con dimensiones de 12 X 9 pulgadas
sizeGrWindow(12,9)
# Mandamos el pdf a carpeta de salida
pdf("03_Output/SampleTree.pdf", width = 12, height = 9)
par(cex = 0.6)
par(mar = c(0,4,2,0))
plot(sampleTree, main = "Sample clustering to detect outliers", sub="", xlab="", cex.lab = 1.5, cex.axis = 1.5, cex.main = 2)
dev.off()

# La figura muestra un único Ootlier (el primero-F2_221), entonces lo debemos remover con la siguiente funciçon:

# Gráficar una línea que muestre el corte
abline(h = 15, col = "red")
# Determinar el cluster bajo la línea
clust<- cutreeStatic(sampleTree, cutHeight = 15, minSize = 10)
table(clust)
# Con lo anterior, el cluster 1 contiene las muestras que queremos guardar (tiene las otras 134) 
# Así que las guardamos en un nuevo dataframe y guardamos el nombre de las columnas y filas como en el antiguo archivo
keepSamples<-(clust==1) 
datExpr<-datExpr0[keepSamples,]
nGenes<-ncol(datExpr)
nSamples<-nrow(datExpr)

#datExpr es con el archivo que vamos a trabajar ya con la información filtrada.


################# PARTE 3

#Ahora leemos los datos demás datos y hacemos coincidir con las muestras de expresión
traitData<-read.csv("01_Raw_data/FemaleLiver-Data/ClinicalTraits.csv")
dim(traitData)
names(traitData)
View(traitData)
# Eliminamos las columnas de información que no trabajaremos 
allTraits<-traitData[, -c(31, 16)] ##Corresponde a notas y comentarios
allTraits<-allTraits[, c(2, 11:36)]
dim(allTraits)
names(allTraits)

# Formamos un marco de datos análogo a los datos de expresióny los datos  clínicos
femaleSamples<-rownames(datExpr) #Colocamos nombres de las muestras en la base filtrada
traitRows<-match(femaleSamples, allTraits$Mice) #mezclamos datos de base filtrada con los clínicos
datTraits<-allTraits[traitRows, -1] #Quitamos la primer columna
rownames(datTraits)<-allTraits[traitRows, 1]
collectGarbage()  #Con esta función colectamos elementos no utilizados sin cambios 

#Ahora tenemos los datos de expresión (datExpr), y los rasgos clínicos (datTraits)
#Antes de continuar con la construcción de redes y la detección de módulos, visualizamos cómo los rasgos clínicos
# y como se relacionan con el dendrograma de la muestra

# Re-clusterizar las muestras 
sampleTree2<- hclust(dist(datExpr), method = "average")
# Convertimos los datos clínicos en un color representativo: blanco significa bajo, rojo alto, gris significa dato perdido
traitColors<-numbers2colors(datTraits, signed = FALSE)
# Gráficamos la muestra del dendogramna y los coloreas debajo de ellos
pdf("03_Output/SampleTreeandTraits.pdf", width = 12, height = 9)
plotDendroAndColors(sampleTree2, traitColors,groupLabels = names(datTraits), main = "Sample dendrogram and trait heatmap")
dev.off()

#El último paso es guardar la expresión relevante y los datos de rasgos 
# para usarlos en los próximos pasos
save(datExpr, datTraits, file = "01_Raw_data/FemaleLiver-Data/FemaleLiver-01-dataInput.RData")



##Network analysis of liver expression data from female mice####

#2.1 Automatic, one-step network construction and module detection

options(stringsAsFactors = FALSE) #Cargamos esta opción previamente, antes de cargar los datos
#Cargamos los dtaos pasados
lnames<-load(file = "01_Raw_data/FemaleLiver-Data/FemaleLiver-01-dataInput.RData")
#La variable lnames contiene los nombres de las variables cargadas
lnames

################# PARTE 1
#Construcción automática de la red de genes e identificación de módulos
#Elección del poder de umbral suave: análisis de la topología de la red
#La construcción de una red de genes ponderada implica la elección del poder de umbral suave (β) al que la coexpresión se plantea la similitud para calcular la adyacencia
#Los autores de  han propuesto elegir el poder de umbral suave basado en el criterio de topología aproximada sin escala. 

#Se usa la función pickSoftThreshold que realiza el análisis de la topología de la red y ayuda al usuario en la elección de una potencia de umbral suave adecuada
#El usuario elige un conjunto de poderes candidatos (la función proporciona valores predeterminados adecuados), y la función devuelve un conjunto de índices de red que deben ser inspeccionados:

# Elegir un grupo de soft-thresholding powers (poder de umbral suave) al azar
powers<- c(c(1:10), seq(from = 12, to=20, by=2))
# Llamamos a la función de topología
library(doParallel) 
sft<-pickSoftThreshold(datExpr, powerVector = powers, verbose = 5)
# Gráficamos los resultados
par(mfrow = c(1,2))
cex1 = 0.9

pdf("03_Output/Scaledependencyandmeanconnectivity.pdf")
# Índice de ajuste de topología sin escala en función del poder de umbral suave
plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2], xlab="Soft Threshold (power)",ylab="Scale Free Topology Model Fit,signed R^2", type="n", main = paste("Scale independence"))
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2], labels=powers,cex=cex1,col="red") #Se colocan los valores de poder en vez de puntos
# Esta línea corresponde al uso de un límite R^2 de h
abline(h=0.90,col="red")
# Conectividad media en función del poder de umbral suave
plot(sft$fitIndices[,1], sft$fitIndices[,5],xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n", main = paste("Mean connectivity"))
text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, cex=cex1,col="red")
dev.off()

#En el ejemplo de elige la potencia 6, que es la potencia más baja para la que encaja la topología sin escala 
#la curva del índice se aplana al alcanzar un valor alto (en este caso, aproximadamente 0,90).

################# PARTE 2
#Construir la red con un simple comando
net<-blockwiseModules(datExpr, power = 6, TOMType = "unsigned", minModuleSize = 30, reassignThreshold = 0, mergeCutHeight = 0.25, numericLabels = TRUE, pamRespectsDendro = FALSE, saveTOMs = TRUE, saveTOMFileBase = "femaleMouseTOM", verbose = 3)

#Con esto podemos ver los modulos y el tamaño de cada uno 
table(net$colors)

#El valor 0 indica genes fuera de los modulos (aquí son 99)
#Ahora lo gráficamos
#Convertimos las eqtiquetas en colores para gráficarlos
mergedColors<-labels2colors(net$colors)
# Gráficamos el dendograma y el modulo de colores debajo 
pdf("03_Output/Dendogramandmodulecolors.pdf")
plotDendroAndColors(net$dendrograms[[1]], mergedColors[net$blockGenes[[1]]], "Module colors", dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05)
dev.off()

#Ahora guardamos la asignación del módulo y la información del gen propio del módulo necesaria para el análisis posterior.
moduleLabels<-net$colors
moduleColors<-labels2colors(net$colors)
MEs<-net$MEs
geneTree<-net$dendrograms[[1]]
save(MEs, moduleLabels, moduleColors, geneTree, file = "01_Raw_data/FemaleLiver-Data/FemaleLiver-02-networkConstruction-auto.RData")



#2.1 Step-by-step network construction and module detection

################# PARTE 1
#A partir de el poder umbral de 6 de la red calculado en el primer paso, se construye primero una matriz de adyacencia
softPower<- 6
adjacency<-adjacency(datExpr, power = softPower)

#Para minimizar los efectos del ruido y las asociaciones falsas, transformamos la adyacencia 
#en una matriz de superposición topológica
TOM<-TOMsimilarity(adjacency)
dissTOM<- 1-TOM #Y después se debe calcular la disimilitud

#Clusterizamos usando TOM
# Empleamos la función clusterización jerárquica 
geneTree<-hclust(as.dist(dissTOM), method = "average")

# Gráficamos el resultado 
pdf("03_Output/GeneclusteringTOMdissimilarity.pdf")
plot(geneTree, xlab="", sub="", main = "Gene clustering on TOM-based dissimilarity", labels = FALSE, hang = 0.04)
dev.off()

#cada hoja, que es una línea vertical corta, corresponde a un gen. 
#Las ramas del dendograma se agrupan densamente en genes interconectados y altamente coexpresados. 


#Para la identificación del módulos usaremos lo siguiente:
# Aquí seleccionan un modulo grande por lo que el tamaño 30 respresenta, el mínimo relativo:
minModuleSize<-30
# Con esto se coloca el modulo de identificación usando el comando "dynamic tree cut":
dynamicMods<-cutreeDynamic(dendro = geneTree, distM = dissTOM, deepSplit = 2, pamRespectsDendro = FALSE, minClusterSize = minModuleSize)
table(dynamicMods)
#Tenemos 22 modulos, nuevamente, 0 son aquellos que salen

#Gráficamos lo anteriror:

# Convertimos las etiquetas númericas en colores
dynamicColors<-labels2colors(dynamicMods)
table(dynamicColors)
# Gráficamos en dendograma con las etiquetas de color debajo
pdf("03_Output/GeneclusteringTOMdissimilarity_dendogramacolors.pdf")
plotDendroAndColors(geneTree, dynamicColors, "Dynamic Tree Cut", dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05, main = "Gene dendrogram and module colors")
dev.off()

#Fusión de módulos cuyos perfiles de expresión son muy similares
#Se pueden identificar módulos cuyos perfiles de expresión son muy similares, es bueno fusionarlos
#ya que sus genes están altamente coexpresados. 
#HAcemos lo siguiente para cuantificar la similitud de coexpresión de módulos completos,
#calcular sus genes propios y agruparlos en su correlación:

# Calculr genes propios
MEList<-moduleEigengenes(datExpr, colors = dynamicColors)
MEs<-MEList$eigengenes

# Calcular la disimilaridad del modulo de genes propios 
MEDiss<- 1-cor(MEs)
# Agruparlos
METree<-hclust(as.dist(MEDiss), method = "average");
# Gráficar resultado
pdf("03_Output/GeneclusteringTOMdissimilarity_dendogramacolors.pdf")
plot(METree, main = "Clustering of module eigengenes", xlab = "", sub = "")
#Los autores seleccionan el corte 0.25, que corresponde a las correlación 0.75
#Observada en el gráfico.
MEDissThres<-0.25
# Se gráfica la línea del corte en el dendograma
abline(h=MEDissThres, col = "red")
dev.off()


# Se usa una función de fusión
merge<- mergeCloseModules(datExpr, dynamicColors, cutHeight = MEDissThres, verbose = 3)
# La fusión de colores
mergedColors<- merge$colors
# Los genes parecidos se quedan en nuevos modulos
mergedMEs<- merge$newMEs

#Para ver estos cambios, se vuelve a gráficar
pdf("03_Output/GenedendroTOMdissimilarity_3_newmoduls.pdf")
plotDendroAndColors(geneTree, cbind(dynamicColors, mergedColors), c("Dynamic Tree Cut", "Merged dynamic"), dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05)
dev.off()

#Guardamos estos datos para siguiente parte
# Renombramos los modulos de colores
moduleColors<- mergedColors
# Nombramos los colores de las etiquetas 
colorOrder<- c("grey", standardColors(50))
moduleLabels<- match(moduleColors, colorOrder)-1
MEs<- mergedMEs
# Guardamos
save(MEs, moduleLabels, moduleColors, geneTree, file = "01_Raw_data/FemaleLiver-02-networkConstruction-stepByStep.RData")




#2.3 Dealing with large datasets: block-wise network construction and module detection
#A partir de el poder umbral de 6 de la red calculado en el primer paso, se construye primero una matriz de adyacencia

################# PARTE 1
#Construcción de red por bloques y detección de módulos
#Vamos a reducir el número de datos a 2000, para este ejemplo, por la capacidad de la computadora:
bwnet <- blockwiseModules(datExpr, maxBlockSize = 2000, power = 6, TOMType = "unsigned", minModuleSize = 30, reassignThreshold = 0, mergeCutHeight = 0.25, numericLabels = TRUE, saveTOMs = TRUE, saveTOMFileBase = "femaleMouseTOM-blockwise", verbose = 3)

# Vamos a hacer una comparación de los resultados de este análisis nuevo con los resultados 
# en la que se analizaron todos los genes
# Retomamos los datos
load(file = "01_Raw_data/FemaleLiver-Data/FemaleLiver-01-dataInput.RData")
# Re-etqiuetamos con colores
bwLabels<- matchLabels(bwnet$colors, moduleLabels)
# Consvertimos las etiquetas en colores para gráficar 
bwModuleColors <- labels2colors(bwLabels)
table(bwLabels)

#Gráficamos
# PDendograma, bloque 1
plotDendroAndColors(bwnet$dendrograms[[1]], bwModuleColors[bwnet$blockGenes[[1]]], "Module colors", main = "Gene dendrogram and module colors in block 1", dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05)
# Dendograma, bloque 2
plotDendroAndColors(bwnet$dendrograms[[2]], bwModuleColors[bwnet$blockGenes[[2]]], "Module colors", main = "Gene dendrogram and module colors in block 2", dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05)

#Comparamos los bloques 1 y 2
plotDendroAndColors(geneTree, cbind(moduleColors, bwModuleColors), c("Single block", "2 blocks"), main = "Single block gene dendrogram and module colors",dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05)

#La inspección visual confirma que existe un excelente acuerdo entre la asignación de módulo individual y por bloque

#Ahora verificamos que los genes propios del módulo de los módulos que se corresponden entre sí en el bloque 1 y en bloque 2
#Primero calculamos los genes propios del módulo en función del bloque único y del bloque de colores del módulo:

singleBlockMEs<- moduleEigengenes(datExpr, moduleColors)$eigengenes
blockwiseMEs<- moduleEigengenes(datExpr, bwModuleColors)$eigengenes

#Ahora los juntamos y calculamos su valor de correlación
single2blockwise<-match(names(singleBlockMEs), names(blockwiseMEs))
signif(diag(cor(blockwiseMEs[, single2blockwise], singleBlockMEs)), 3)

#Cada número anterior representa la correlación de un gen propio de un solo bloque con su contraparte de bloque correspondiente. 
#Todas las correlaciones están muy cerca de 1 (el gen turquesa cambió de orientación), lo que nuevamente indica que el
# los análisis por bloques y por bloques conducen a resultados muy similares




# 3. *Relating modules to external clinical traits and identifying important genes* 
#Retomamos la informaicón guardada
# Expresión and datos clínicos
lnames <- load(file = "01_Raw_data/FemaleLiver-Data/FemaleLiver-01-dataInput.RData")
lnames
# La red guardada
lnames <- load(file = "01_Raw_data/FemaleLiver-Data/FemaleLiver-02-networkConstruction-auto.RData")
lnames

#Primero cuantificamos la relación modulo-rasgos clínicos 
# Definimos número de genes y muestars
nGenes <- ncol(datExpr)
nSamples <- nrow(datExpr)
# Recalculamos MEs con etiquetas de colores
MEs0 <- moduleEigengenes(datExpr, moduleColors)$eigengenes
MEs <- orderMEs(MEs0)
moduleTraitCor <- cor(MEs, datTraits, use = "p")
moduleTraitPvalue <- corPvalueStudent(moduleTraitCor, nSamples)

#Gráficamos para revisar de manera general estás relaciones, a diferencia de hacerlo en la tabla que pòsee muchos datos
# Will display correlations and their p-values
textMatrix <- paste(signif(moduleTraitCor, 2), "\n(", signif(moduleTraitPvalue, 1), ")", sep = "");
dim(textMatrix) <- dim(moduleTraitCor)
par(mar = c(6, 8.5, 3, 3))
# Mostramos los valores de correlacion en un mapa de calor
pdf("03_Output/Module-trait relationships.pdf")
labeledHeatmap(Matrix = moduleTraitCor, xLabels = names(datTraits), yLabels = names(MEs), ySymbols = names(MEs), colorLabels = FALSE, colors = blueWhiteRed(50), textMatrix = textMatrix, setStdMargins = FALSE, cex.text = 0.5, zlim = c(-1,1), main = paste("Module-trait relationships"))
dev.off()

#Relación del gen con el rasgo y módulos importantes: Significado del gen y módulo afiliación
#Cuantificamos las asociaciones de genes individuales con nuestro rasgo de interés (peso) definiendo Gene Significance GS como
#(el valor absoluto de) la correlación entre el gen y el rasgo. 
#Para cada módulo, también definimos una cantidad medida de la pertenencia al módulo MM como la correlación del gen propio del módulo y el perfil de expresión génica. 
#Esta nos permite cuantificar la similitud de todos los genes en la matriz con cada módulo.

# Definir la variable de peso, seleccionando la columna de datTrait
weight <- as.data.frame(datTraits$weight_g)
names(weight) <- "weight"
# Nombres (colores) de los modulos 
modNames <- substring(names(MEs), 3)
geneModuleMembership <- as.data.frame(cor(datExpr, MEs, use = "p"))
MMPvalue <- as.data.frame(corPvalueStudent(as.matrix(geneModuleMembership), nSamples))

names(geneModuleMembership) <- paste("MM", modNames, sep="")
names(MMPvalue) <- paste("p.MM", modNames, sep="")

geneTraitSignificance <- as.data.frame(cor(datExpr, weight, use = "p"))
GSPvalue <- as.data.frame(corPvalueStudent(as.matrix(geneTraitSignificance), nSamples))

names(geneTraitSignificance) <- paste("GS.", names(weight), sep="")
names(GSPvalue) <- paste("p.GS.", names(weight), sep="")

#Intramodular analysis: identifying genes with high GS and MM
#Usando las medidas de GS y MM, podemos identificar genes que tienen una gran importancia para el peso, 
#así como un alto valor para acceder a un módulo interesante 

module <- "brown"
column <- match(module, modNames)
moduleGenes <- moduleColors==module
sizeGrWindow(7, 7)
par(mfrow = c(1,1))
pdf("03_Output/Module membership vs. gene significance\n.pdf")
verboseScatterplot(abs(geneModuleMembership[moduleGenes, column]), abs(geneTraitSignificance[moduleGenes, 1]), xlab = paste("Module Membership in", module, "module"), ylab = "Gene significance for body weight", main = paste("Module membership vs. gene significance\n"), cex.main = 1.2, cex.lab = 1.2, cex.axis = 1.2, col = module)
dev.off()

#Summary output of network analysis results
#Hemos encontrado módulos con alta asociación con nuestro rasgo de interés, y hemos identificado sus jugadores centrales por
#la medida Membresía del módulo. Ahora combinamos esta información estadística con la anotación de genes y escribimos un
#archivo que resume los resultados más importantes y se puede inspeccionar en un software de hoja de cálculo.

names(datExpr)
#lo siguiente devolverá todos los ID de sonda incluidos en el análisis
names(datExpr)[moduleColors=="brown"]

#Para facilitar la interpretación de los resultados, utilizamos una sonda archivo de anotación proporcionado por las matrices de expresión 
#para conectar los ID de sonda a los nombres de genes y números de identificación universalmente reconocidos 
annot <- read.csv(file = "01_Raw_data/FemaleLiver-Data/GeneAnnotation.csv")
dim(annot)
names(annot)
probes <- names(datExpr)
probes2annot <- match(probes, annot$substanceBXH)
# Los siguiente indica el número de pruebas sin anotación:
sum(is.na(probes2annot))
# Se regresa el valor 0

#Ahora creamos un data frame con la información de las pruebas: probe ID, gene symbol, Locus Link ID, 
#module color, gene significance para el peso, y module membership y valores p.  
#Los modulis se ordenen por su significacnai en peso (en la derecha)

# Crear el dataframe
geneInfo0 <- data.frame(substanceBXH = probes, geneSymbol = annot$gene_symbol[probes2annot], LocusLinkID = annot$LocusLinkID[probes2annot], moduleColor = moduleColors, geneTraitSignificance, GSPvalue)
# Ordenar sus modulo por sgnificancia en peso
modOrder <-order(-abs(cor(MEs, weight, use = "p")))
# Agregar modulos por información de cada miembro en un orden elegido 
for (mod in 1:ncol(geneModuleMembership)) { 
        oldNames <- names(geneInfo0)
        geneInfo0 <- data.frame(geneInfo0, geneModuleMembership[, modOrder[mod]], MMPvalue[, modOrder[mod]]);
        names(geneInfo0) <- c(oldNames, paste("MM.", modNames[modOrder[mod]], sep=""),
        paste("p.MM.", modNames[modOrder[mod]], sep=""))
}

# Ordenar los genes en geneInfo varaibles primero por modulo de color
# después porgeneTraitSignificance
geneOrder <- order(geneInfo0$moduleColor, -abs(geneInfo0$GS.weight))
geneInfo <- geneInfo0[geneOrder, ]

#Loa pasamos a csv
write.csv(geneInfo, file = "01_Raw_data/geneInfo.csv")




#Interfacing network analysis with other data such as functional annotation and gene ontology
#Una opción es simplemente exportar una lista de identificadores de genes que se pueden usar como entrada para varias ontologías de genes populares.
# Leemos el archivo de anotación
annot <- read.csv(file = "01_Raw_data/FemaleLiver-Data/GeneAnnotation.csv")
# Unimos las pruebas del set de datos con los Ids pruebas en el archivo de anotación
probes <- names(datExpr)
probes2annot <- match(probes, annot$substanceBXH)
# Obtenemos el locus de correspondencia con el locus ID 
allLLIDs <- annot$LocusLinkID[probes2annot];
# Seleccionamos los modulos de interés
intModules <- c("brown", "red", "salmon")
for (module in intModules) {
        # Seleccionar modulo de pruebas
        modGenes <- (moduleColors==module)
        # Obtenemos su códigos entrez ID codes
        modLLIDs <- allLLIDs[modGenes];
        # Lo escribimos en eun archivo
        fileName <- paste("LocusLinkIDs-", module, ".txt", sep="");
        write.table(as.data.frame(modLLIDs), file = fileName, row.names = FALSE, col.names = FALSE)
}

# Como en el análisis de enriquecimiento, usaremos todas las pruebasen el análisis 
fileName <- paste("LocusLinkIDs-all.txt", sep="")
write.table(as.data.frame(allLLIDs), file = fileName, row.names = FALSE, col.names = FALSE)

##Enrichment analysis directly within R
#Cargamos los siguientes paquetes
library(GO.db)
library(AnnotationDbi)
#El específico para la especie, en este caso ratón, con la siguiente función llamamos a estos datos 
GOenr <- GOenrichmentAnalysis(moduleColors, allLLIDs, organism = "mouse", nBestP = 10)
#Obervamos los datos que nos otorgó la función
tab <- GOenr$bestPTerms[[4]]$enrichment

#Esta es una tabla de enriquecimiento que contiene los 10 mejores términos para cada módulo presente 
#en moduleColors, para acceder a los nombres dse usa:

names(tab)

#Aquí lo guardamos en una tabla de excel, para evitar usar la función
write.table(tab, file = "GOEnrichmentTable.csv", sep = ",", quote = TRUE, row.names = FALSE)



# 5. *Network visualization using WGCNA functions* 
#Podemos visualizarlo en un heatmap
# Calculamos una superposición topological de nuevo: es más eficiente si guardamos el TOM (que ya hicimos- disstOM)
dissTOM = 1-TOMsimilarityFromExpr(datExpr, power = 6)
# Transform amos dissTOM con un valor de poder para hacer las conexiones  moderadamente más fuertes en el heat map
plotTOM <- dissTOM^7
# Establecemos una diagonal en NA para una trama más agradable
diag(plotTOM) = NA
# Gráficamos
pdf("03_Output/networkheatmap,allgenes.pdf")
TOMplot(plotTOM, geneTree, moduleColors, main = "Network heatmap plot, all genes")
dev.off()

#Visualizar la red de genes propios
#A menudo es interesante estudiar las relaciones entre los módulos encontrados. 
#Se pueden utilizar los genes propios como perfiles representativos y cuantificar la similitud 
#del módulo mediante la correlación de genes propios.

# Recalculamos los modulos de gene spropios
MEs <- moduleEigengenes(datExpr, moduleColors)$eigengenes
# Islamos el peso de los rasgos clínicos 
weight <- as.data.frame(datTraits$weight_g)
names(weight) = "weight"
# Agregamos el peso que existe al modulo de genes propios 
MET <- orderMEs(cbind(MEs, weight))
# Gráficamos la relación entre genes propios y los ragos clínicos 
pdf("03_Output/EigenDendogram.pdf")
par(cex = 0.9)
plotEigengeneNetworks(MET, "Eigen gen dendogram", marDendro = c(0,4,1,2), marHeatmap = c(3,4,1,2), cex.lab = 0.8, xLabelsAngle = 90)
dev.off()



# 6. *Export of networks to external software* 
#Este caso vamos a usar y exportar los datos a Cytoscape
# Recalculamos la superposición topologica
TOM <- TOMsimilarityFromExpr(datExpr, power = 6)
# Leemos el texto de anotación
annot <- read.csv(file = "01_Raw_data/FemaleLiver-Data/GeneAnnotation.csv")
# Seleccionamos modulos
modules <- c("brown", "red")
# Seleccionamos modulos de prueba
probes <- names(datExpr)
inModule <- is.finite(match(moduleColors, modules))
modProbes <- probes[inModule]
modGenes <- annot$gene_symbol[match(modProbes, annot$substanceBXH)]
# Seleccionamos la superposición topologica correspondiente  
modTOM <- TOM[inModule, inModule]
dimnames(modTOM) <- list(modProbes, modProbes)
# Exportamos la red de conexiones y nodos que pueda leer cytoscape  
cyt <- exportNetworkToCytoscape(modTOM,
                               edgeFile = paste("CytoscapeInput-edges-", paste(modules, collapse="-"), ".txt", sep=""),
                               nodeFile = paste("CytoscapeInput-nodes-", paste(modules, collapse="-"), ".txt", sep=""),
                               weighted = TRUE,
                               threshold = 0.02,
                               nodeNames = modProbes,
                               altNodeNames = modGenes,
                               nodeAttr = moduleColors[inModule])