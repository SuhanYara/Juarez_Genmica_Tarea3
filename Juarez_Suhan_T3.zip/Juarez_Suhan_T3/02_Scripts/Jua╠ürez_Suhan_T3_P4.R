#### Red de señalización####
# A partir de la red de señalización mostrada en la figura 1.



################# PARTE 3
# Encuentra y discute biológicamente el significado de los atractores (Usa BoolNet)

#  A partir de la reglas que colocamos en la vía, creamos un archivo de texto y lo leeremos con BoolNet

library(BoolNet)
red_SenBoo<-loadNetwork("01_Raw_data/RedSenalizacion.txt")
red_SenBoo

plotNetworkWiring(red_SenBoo)

atractores<-getAttractors(red_SenBoo)
atractores

plotAttractors(atractores)

plotStateGraph(atractores) ### No se puede!

